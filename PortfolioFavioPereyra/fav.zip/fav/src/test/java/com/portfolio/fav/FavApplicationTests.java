package com.portfolio.fav;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FavApplicationTests {

	@Test
	void contextLoads() {
	}

}
